const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const root = path.join(__dirname, '..');
const read = f => fs.readFileSync(path.join(root, f), 'utf8');
const manifest = JSON.parse(read('manifest.webmanifest'));
assert.equal(manifest.start_url, './');
assert.equal(manifest.scope, './');
assert.equal(manifest.display, 'standalone');
assert(manifest.icons.some(x => x.sizes === '192x192'));
assert(manifest.icons.some(x => x.sizes === '512x512' && x.purpose === 'maskable'));
for(const f of ['index.html','styles.css','app.js','sw.js','manifest.webmanifest','assets/apple-touch-icon.png','assets/icon-192.png','assets/icon-512.png','assets/icon-maskable-512.png']) {
  assert(fs.existsSync(path.join(root, f)), f + ' missing');
}
assert(read('index.html').includes('apple-mobile-web-app-capable'));
assert(read('index.html').includes('apple-touch-icon'));
assert(read('sw.js').includes('self.registration.scope'));
assert(read('app.js').includes('const records = [];'));
assert(!read('app.js').includes('rmuifv4kt'));
console.log('PASS: iOS metadata, manifest, service worker, shell files, and blank public dataset');
