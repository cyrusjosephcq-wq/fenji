const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const source = fs.readFileSync(path.join(__dirname, '..', 'app.js'), 'utf8');
const boot = source.indexOf('  initializeApp().catch(err => {');
assert(boot > 0, 'startup hook not found');
const isolated = source.slice(0,boot) + `
  window.__storeTest = {
    loadState,
    readLegacyState,
    writeIndexedState,
    getState:() => state,
    useState:(value) => { state = value; },
    saveState,
    storageMode:() => storageMode,
    didMigrateLegacy:() => didMigrateLegacy,
    db:() => activeDatabase
  };
})();`;

const cloned = o => structuredClone(o);
function makeFakeIndexedDB({failOpen=false, failWrite=false}={}) {
  const dbs = new Map();
  function open(name) {
    const req = {};
    setImmediate(() => {
      if (failOpen) { req.error = Error('opening blocked'); req.onerror?.(); return; }
      let entry = dbs.get(name);
      const first = !entry;
      if (first) { entry = {stores:new Map(),writeQueue:Promise.resolve()}; dbs.set(name,entry); }
      const db = {
        objectStoreNames: {contains:(n)=>entry.stores.has(n)},
        createObjectStore:(n) => entry.stores.set(n,new Map()),
        close() {},
        transaction(store,mode) {
          if (!entry.stores.has(store)) throw Error('missing store');
          const tx = {
            objectStore:() => ({
              get:(key) => {
                const req2={};
                setImmediate(() => {
                  req2.result=cloned(entry.stores.get(store).get(key));
                  req2.onsuccess?.();
                });
                return req2;
              },
              put:(value,key) => {
                const snap=cloned(value);
                entry.writeQueue=entry.writeQueue.then(()=>new Promise(resolve=>setImmediate(resolve))).then(()=>{
                  if (failWrite) {tx.error=Error('write blocked');tx.onerror?.();return;}
                  entry.stores.get(store).set(key,snap);
                  tx.oncomplete?.();
                });
                return {};
              }
            })
          };
          return tx;
        },
        set onversionchange(fn) {this._versionchange=fn;}
      };
      req.result=db;
      if(first) req.onupgradeneeded?.();
      req.onsuccess?.();
    });
    return req;
  }
  return {open,dbs};
}
function makeLocalStorage() {
  const map=new Map();
  return {
    getItem:k=>map.has(k)?map.get(k):null,
    setItem:(k,v)=>map.set(k,String(v)),
    removeItem:k=>map.delete(k),
    map
  };
}
function makeEnv(db,local) {
  const window={indexedDB:db,addEventListener:()=>{}};
  const document={addEventListener:()=>{}};
  const context={window,document,indexedDB:db,localStorage:local,console,Date,Math,Set,Map,Number,String,JSON,Promise,setTimeout,clearTimeout};
  vm.runInNewContext(isolated, context, {filename:'app.js',timeout:2000});
  return window.__storeTest;
}
const sampleRecord={id:'record_1',subjectId:'math',name:'月考',date:'2026-10-10',fullMark:100,score:92,createdAt:1};
async function main() {
  const db=makeFakeIndexedDB(), local=makeLocalStorage();
  const first=makeEnv(db,local);
  const blank=await first.loadState();
  assert.equal(first.storageMode(),'indexeddb');
  assert.equal(blank.records.length,0);
  const state={...cloned(blank),records:[sampleRecord]};
  first.useState(state);
  assert.notEqual(await first.saveState({autoSnapshot:false}),false);
  assert.equal((await makeEnv(db,local).loadState()).records.length,1,'reload must retain record');

  // Simulate a legacy backup published later; IndexedDB stays authoritative.
  local.setItem('score-atlas-v6', JSON.stringify({...blank,records:[{...sampleRecord,score:1}]}));
  const reload=await makeEnv(db,local).loadState();
  assert.equal(reload.records[0].score,92,'stale localStorage must not overwrite IDB');

  // Rapid saves enqueue independent snapshots in event order.
  const edits=makeEnv(db,local);await edits.loadState();edits.useState(reload);
  edits.getState().records[0].score=66;
  const p1=edits.saveState({autoSnapshot:false});
  edits.getState().records[0].score=77;
  const p2=edits.saveState({autoSnapshot:false});
  await Promise.all([p1,p2]);
  assert.equal((await makeEnv(db,local).loadState()).records[0].score,77);

  // Import from an older localStorage slot only when database is fresh.
  const newDB=makeFakeIndexedDB(), oldLocal=makeLocalStorage();
  oldLocal.setItem('score-atlas-v5', JSON.stringify({...blank, records:[sampleRecord]}));
  const migrated=makeEnv(newDB,oldLocal);
  const migratedState=await migrated.loadState();
  assert.equal(migratedState.records.length,1,'old v5 records should migrate');
  assert.equal(migrated.didMigrateLegacy(),true);
  assert(oldLocal.getItem('score-atlas-v5'),'legacy backup should not be deleted');
  assert.equal((await makeEnv(newDB,oldLocal).loadState()).records.length,1);

  // Deliberate clearing stays cleared, rather than resurrecting legacy records.
  migrated.useState({...migratedState,records:[]});
  await migrated.saveState({autoSnapshot:false});
  assert.equal((await makeEnv(newDB,oldLocal).loadState()).records.length,0);

  // If IDB is inaccessible, fall back to read legacy without destroying data.
  const badDB=makeFakeIndexedDB({failOpen:true}), fallback=makeEnv(badDB,oldLocal);
  assert.equal((await fallback.loadState()).records.length,1);
  assert.equal(fallback.storageMode(),'localStorage');
  console.log('PASS: IndexedDB initialization, reload, ordered writes, legacy migration, reset, fallback');
}
main().catch(err=>{console.error(err);process.exitCode=1;});
