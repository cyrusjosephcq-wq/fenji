# 用 GitHub 在 iPhone 上安装「分迹」

1. 下载并**解压** `fenji-ios-pwa-github-pages.zip`。
2. 前往 https://github.com/new ，创建公开仓库 `fenji-pwa`。
3. 进入仓库，选 `Add file` → `Upload files`。上传**解压目录内部**的内容。检查仓库列表顶层有 `index.html`，以及 `app.js`、`styles.css`、`manifest.webmanifest`、`sw.js`、`assets` 文件夹（不要只是一个 ZIP）。
4. `Settings` → `Pages` → `Source: Deploy from a branch` → `Branch: main / (root)` → `Save`。
5. 几分钟后使用 `https://你的用户名.github.io/fenji-pwa/` 打开。若找不到网址，请回到 Pages 页面查看发布状态和地址。
6. iPhone 上用 Safari 打开网址 → 分享 → 添加到主屏幕 → 启用「作为网页 App 打开」（如果显示）→ 添加。
7. 已在同一个网址、同一个浏览器数据容器里使用旧版的用户，首次打开新版本会自动把 localStorage 成绩迁移到 IndexedDB；Safari 与主屏幕 App、不同网址之间可能不共享存储，因此这些情况下请使用「我的」里的 JSON 导出/导入迁移。记得定期备份。
8. **升级原有仓库：** 不需要重新建仓库。进入原有 GitHub 仓库上传本包解压后的所有文件，选择覆盖同名文件并提交；保留原来的 Pages 设置。下次联网打开即可获取新版本。

注意：**勿上传私人 JSON 备份**。IndexedDB 仅保存在当前设备，PWA 不会自动同步个人数据；GitHub Pages 不负责存储成绩。

官方资料：
- GitHub Pages: https://docs.github.com/en/pages/getting-started-with-github-pages/configuring-a-publishing-source-for-your-github-pages-site
- iPhone 安装网页 App: https://support.apple.com/zh-cn/guide/iphone/iphea86e5236/27/ios/27
