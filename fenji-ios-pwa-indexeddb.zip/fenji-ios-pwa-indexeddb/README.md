# 分迹 Score Atlas v6.3.1 — iPhone/iPad PWA（IndexedDB 版）

**本项目已是可直接托管的纯静态网站，无需运行 npm install 或执行构建。**
首页 `index.html` 必须放在 GitHub 仓库根目录；不要仅上传 ZIP，也不要将整个解压后的文件夹作为仓库的次级目录。

## 发布到 GitHub Pages（浏览器操作）

1. 登录 https://github.com ，创建新仓库（New repository），例如 `fenji-pwa`；GitHub Free 可以使用 Public 仓库。
2. 解压本 ZIP，打开 `fenji-ios-pwa-github-pages` 文件夹，把里面**所有文件和文件夹**上传到新仓库根目录（根目录必须直接包含 `index.html`、`app.js`、`styles.css`、`sw.js`、`manifest.webmanifest`、`assets/`）。在仓库页面可选择 **Add file → Upload files → Commit changes**。请别只上传 ZIP。
3. 打开仓库 **Settings → Pages → Build and deployment**：`Source` 选 `Deploy from a branch`，`Branch` 选 `main`，文件夹选 `/(root)`，然后 **Save**。
4. 等待 GitHub Pages 部署完成，打开 `https://你的用户名.github.io/fenji-pwa/`，务必使用 HTTPS，首次访问要在线加载。
5. iPhone 打开 **Safari** 访问此地址 → 分享按钮 → **添加到主屏幕** → 如出现「作为网页 App 打开」则启用 → 添加。在主屏幕点「分迹」图标即可独立运行。
6. 保持在线打开一次，使 Service Worker 完成缓存，然后可以断网测试。更新部署后需联网打开一次以获取新版，个别情况下要完全退出并重开。

## 特别说明：数据与隐私

- 这份 **GitHub 发布版已清除原项目内置的 6 条成绩和原始成绩示例**；也不包含原来可能显示个人成绩的截图。首次启动是空白成绩，原本的功能、学科和中考配置保留。
- **GitHub Pages 站点是公开可访问的**。不要将真实成绩 JSON 备份、私人文件、截图或访问密钥提交进仓库。
- 成绩、学科、设置、快照保存在当前浏览器 / 主屏幕 Web App 的 **IndexedDB 本地数据库**（并非 GitHub 服务器）。它们不会因为使用同一个网址就自动同步到 iPad、Safari 或另一部 iPhone。浏览器清理网站数据、卸载应用等情况可能导致丢失。
- **旧版升级自动迁移：** 如果旧版与新版在相同网站来源、相同 Safari/PWA 数据容器内运行，首次打开时会把 `score-atlas-v6` / v5 / v4 / v3 的 localStorage 记录迁移至 IndexedDB；迁移写入完成后才会使用新数据库。旧 localStorage 记录作为安全备份保留，不会自动删除。
- **iOS 数据隔离提醒：** iPhone 主屏幕 Web App 与 Safari 标签页可能采用不同的数据容器；更换 GitHub 用户名/仓库地址也会改变网站来源。这些情形**无法自动跨源迁移**，必须通过 JSON 导出 / 导入迁移。
- **容量与保障：** IndexedDB 配额取决于 iOS 存储空间与系统策略，不代表永久保存；存储被清理、设备丢失或卸载应用都可能丢数据。若浏览器禁用 IndexedDB，应用会显式提示并尝试 localStorage 兼容存储；写入失败会提示用户备份。
- 用旧版应用的「我的 → 导出全部数据」得到 JSON 文件，在新版**主屏幕 App**的「我的 → 导入数据」进行恢复；iOS 导出时可在分享菜单中选择「存储到文件」。建议定期备份。
- 本项目不提供云端同步、App Store IPA 或系统级数据恢复；离线模式必须先通过 HTTPS 打开一次。

## 开发和测试

可直接运行 `python serve.py` 用电脑打开 `http://127.0.0.1:8765` 调试（localhost 支持 Service Worker），或执行 `npm test` 检查 PWA 文件。

文件角色：`index.html` 入口、`app.js` 主应用、`styles.css` 布局、`manifest.webmanifest` 安装信息、`sw.js` 离线缓存、`assets/` iOS / PWA 图标、`.nojekyll` 用于 GitHub Pages 直接发布文件。
